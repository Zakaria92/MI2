"use strict";
/*global $ */


var bewegingLinks = 0;
var left = 32;
    
$(document).keydown(function (e) { switch (e.which) { case left: $("#muis").animate({ "left": "-=10px" }, 0); break; }
                                 });